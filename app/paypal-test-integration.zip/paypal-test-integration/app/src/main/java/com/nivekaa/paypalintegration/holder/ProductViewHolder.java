package com.nivekaa.paypalintegration.holder;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.nivekaa.paypalintegration.R;

public class ProductViewHolder extends RecyclerView.ViewHolder {
    public TextView price;
    public TextView name;
    public RatingBar rate;
    public ImageView photo;
    public CardView btnAddToCart;
    public ProductViewHolder(@NonNull View itemView) {
        super(itemView);
        price = (TextView)itemView.findViewById(R.id.price);
        name = (TextView)itemView.findViewById(R.id.title);
        rate = (RatingBar) itemView.findViewById(R.id.rate);
        photo = (ImageView)itemView.findViewById(R.id.photo);
        btnAddToCart = (CardView)itemView.findViewById(R.id.btn_add_to_cart);
    }
}
