package com.nivekaa.paypalintegration;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nivekaa.paypalintegration.adapter.LabelAdapter;
import com.nivekaa.paypalintegration.adapter.ProductAdapter;
import com.nivekaa.paypalintegration.listener.OnAddToCartListener;
import com.nivekaa.paypalintegration.model.LabelVM;
import com.nivekaa.paypalintegration.model.OrderItemVM;
import com.nivekaa.paypalintegration.model.ProductVM;
import com.nivekaa.paypalintegration.storage.DBHelper;
import com.paypal.paypalretailsdk.Merchant;
import com.paypal.paypalretailsdk.PaymentDevice;
import com.paypal.paypalretailsdk.RetailSDK;
import com.paypal.paypalretailsdk.RetailSDKException;
import com.paypal.paypalretailsdk.SdkCredential;

import java.util.Arrays;
import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class MainActivity extends AppCompatActivity implements OnAddToCartListener {
    private final String TAG = this.getClass().getSimpleName();
    private RecyclerView labelRecyclerView;
    private RecyclerView productRecyclerView;
    private FrameLayout yellowCircleCart;
    private TextView countCartTextView;
    private TextView errorTextView;
    private DBHelper dbHelper;
    private int alertCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(false);
            actionBar.setDisplayHomeAsUpEnabled(false);
            actionBar.setDisplayShowHomeEnabled(false);
        }
        dbHelper = DBHelper.getInstance(this);
        alertCount = dbHelper.getAllOrders().size();
        initView();
        mountLabelComponent();
        mountProductComponent();
    }

    @Override
    protected void onStart() {
        super.onStart();
        initializePaypalMerchant();
    }

    private void mountProductComponent() {
        List<ProductVM> vms = dbHelper.getAllProducts();
        ProductAdapter productAdapter = new ProductAdapter(this, vms, this);
        productRecyclerView.setAdapter(productAdapter);
        productRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
    }

    private void initView() {
        this.labelRecyclerView = (RecyclerView) findViewById(R.id.labelRv);
        this.productRecyclerView = (RecyclerView) findViewById(R.id.productRv);
        this.errorTextView = (TextView) findViewById(R.id.error);
    }

    private void mountLabelComponent() {
        List<LabelVM> vms = Arrays.asList(
                new LabelVM("Shoes"),
                new LabelVM("Pants"),
                new LabelVM("T-shirts"),
                new LabelVM("Hats"),
                new LabelVM("Bags")
        );
        LabelAdapter labelAdapter = new LabelAdapter(vms);
        labelRecyclerView.setAdapter(labelAdapter);
        labelRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_notification:
                Toast.makeText(this, "Notification action selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_cart:
                Toast.makeText(this, "Cart action selected", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, CartActivity.class));
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.manu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        final MenuItem alertMenuItem = menu.findItem(R.id.action_cart);
        FrameLayout rootView = (FrameLayout) alertMenuItem.getActionView();
        yellowCircleCart = (FrameLayout) rootView.findViewById(R.id.view_cart_circle);
        countCartTextView = (TextView) rootView.findViewById(R.id.view_cart_badge_count);

        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOptionsItemSelected(alertMenuItem);
            }
        });
        updateAlertIcon();
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public void addProduct(ProductVM product) {
        Toast.makeText(this, product.getName() + " has been added to cart", Toast.LENGTH_SHORT).show();
        OrderItemVM orderItem = new OrderItemVM(product, 1);
        dbHelper.addOrder(orderItem);
        alertCount++;
        updateAlertIcon();
    }

    private void updateAlertIcon() {
        if (0 < alertCount && alertCount < 10) {
            countCartTextView.setText(String.valueOf(alertCount));
        } else {
            countCartTextView.setText(""); // if alert count extends into two digits, just show the red circle
        }
        yellowCircleCart.setVisibility((alertCount > 0) ? VISIBLE : GONE);
    }


    // PayPal SDK Center

    private void initializePayPalSDK() {
        try {
            RetailSDK.initialize(this.getApplicationContext(), new RetailSDK.AppState() {
                @Override
                public Activity getCurrentActivity() {
                    return MainActivity.this;
                }

                @Override
                public boolean getIsTabletMode() {
                    return false;
                }
            });
        } catch (RetailSDKException e) {
            e.printStackTrace();
            addErrorMessage(e.getDeveloperMessage());
        }

        initializePaypalMerchant();
    }
    private void initializePaypalMerchant() {
        try {
            SdkCredential credential = new SdkCredential("environment", "access-token");
            credential.setTokenRefreshCredentials("refresh URL to use to refresh access token after expiry");
            RetailSDK.initializeMerchant(credential, new RetailSDK.MerchantInitializedCallback() {
                @Override
                public void merchantInitialized(final RetailSDKException error, final Merchant merchant) {
                    if (error != null) {
                        MainActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Log.d(TAG, "RetailSDK initialize on Error:" + error.toString());
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setTitle(error.getDeveloperMessage());

                                builder.setCancelable(false);
                                builder.setNeutralButton("Okay", new DialogInterface.OnClickListener()
                                {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which)
                                    {
                                        Log.d(TAG, "RetailSDK Initialize error AlertDialog onClick");
                                        dialog.dismiss();
                                        finish();
                                    }
                                });
                                builder.show();
                            }
                        });
                    }
                    else {
                        Toast.makeText(MainActivity.this, "The SDK is successfully configured", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }catch (RetailSDKException e) {
            e.printStackTrace();
            errorTextView.setText(e.getDeveloperMessage());
            addErrorMessage(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            addErrorMessage(e.getMessage());
        }
    }

    private void addErrorMessage(String newErr) {
        String currentError = errorTextView.getText().toString();
        errorTextView.setVisibility(VISIBLE);
        errorTextView.setBackgroundColor(getResources().getColor(R.color.colorError));
        errorTextView.setTextColor(getResources().getColor(R.color.colorProductRate));
        if (currentError != null) {
            errorTextView.setText(String.format("%s\n%s", currentError, newErr));
        }
    }


    private void addSuccessMessage(String msg) {
        String currentError = errorTextView.getText().toString();
        errorTextView.setVisibility(VISIBLE);
        errorTextView.setBackgroundColor(getResources().getColor(R.color.colorSuccess));
        errorTextView.setTextColor(getResources().getColor(android.R.color.white));
        if (currentError != null) {
            errorTextView.setText(String.format("%s\n%s", currentError, msg));
        }
    }
}
