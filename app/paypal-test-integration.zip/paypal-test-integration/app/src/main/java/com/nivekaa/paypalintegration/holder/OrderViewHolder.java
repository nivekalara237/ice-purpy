package com.nivekaa.paypalintegration.holder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.nivekaa.paypalintegration.R;

public class OrderViewHolder extends RecyclerView.ViewHolder {
    public TextView name;
    public TextView price;
    public ImageView image;
    public ImageButton increateQte;
    public ImageButton decreateQte;
    public EditText qte;
    public OrderViewHolder(@NonNull View itemView) {
        super(itemView);
        name = (TextView)itemView.findViewById(R.id.title);
        price = (TextView)itemView.findViewById(R.id.price);
        image = (ImageView) itemView.findViewById(R.id.photo);
        increateQte = (ImageButton) itemView.findViewById(R.id.increase_qte);
        decreateQte = (ImageButton) itemView.findViewById(R.id.decrease_qte);
        qte = (EditText) itemView.findViewById(R.id.qte);
    }
}
