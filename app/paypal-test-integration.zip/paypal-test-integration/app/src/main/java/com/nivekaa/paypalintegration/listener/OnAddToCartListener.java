package com.nivekaa.paypalintegration.listener;

import com.nivekaa.paypalintegration.model.ProductVM;

public interface OnAddToCartListener {
    void addProduct(ProductVM product);
}
