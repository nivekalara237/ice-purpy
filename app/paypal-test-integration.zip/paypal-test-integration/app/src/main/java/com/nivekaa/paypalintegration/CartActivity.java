package com.nivekaa.paypalintegration;

import android.annotation.SuppressLint;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nivekaa.paypalintegration.adapter.OrderApdater;
import com.nivekaa.paypalintegration.listener.OnXxCreaseQteItemListener;
import com.nivekaa.paypalintegration.model.OrderItemVM;
import com.nivekaa.paypalintegration.storage.DBHelper;

import java.util.Arrays;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class CartActivity extends AppCompatActivity implements OnXxCreaseQteItemListener {
    private RecyclerView cartRecyclerView;
    private FrameLayout yellowCircleCart;
    private TextView countCartTextView;
    private TextView prize;
    private DBHelper dbHelper;
    private int alertCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(false);
            actionBar.setDisplayHomeAsUpEnabled(false);
            actionBar.setDisplayShowHomeEnabled(false);
        }
        dbHelper = DBHelper.getInstance(this);
        alertCount = dbHelper.getAllOrders().size();
        initView();
        OrderApdater apdater = new OrderApdater(this, dbHelper.getAllOrders(), this);
        cartRecyclerView.setAdapter(apdater);
        cartRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        updatePrize();
    }

    private void initView() {
        cartRecyclerView = (RecyclerView)findViewById(R.id.cartRv);
        prize = (TextView) findViewById(R.id.prize);
    }

    private void updatePrize() {
        float prizze = 0.0F;
        for (OrderItemVM ordered: dbHelper.getAllOrders()) {
            prizze  = prizze + ordered.getQuantity() * ordered.getProduct().getPrice().floatValue();
        }
        prize.setText(String.format("( $%s )", prizze));
    }

    @Override
    public void increase(OrderItemVM order) {
        order.setQuantity(order.getQuantity() + 1);
        int i = dbHelper.updateOrder(order);
        updatePrize();
    }

    @Override
    public void decrease(OrderItemVM order) {
        order.setQuantity(order.getQuantity() - 1);
        int i = dbHelper.updateOrder(order);
        updatePrize();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_notification:
                Toast.makeText(this, "Notification action selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_cart:
                Toast.makeText(this, "Cart action selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.manu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        final MenuItem alertMenuItem = menu.findItem(R.id.action_cart);
        FrameLayout rootView = (FrameLayout) alertMenuItem.getActionView();
        yellowCircleCart = (FrameLayout) rootView.findViewById(R.id.view_cart_circle);
        countCartTextView = (TextView) rootView.findViewById(R.id.view_cart_badge_count);

        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOptionsItemSelected(alertMenuItem);
            }
        });
        updateAlertIcon();

        return super.onPrepareOptionsMenu(menu);
    }


    private void updateAlertIcon() {
        if (0 < alertCount && alertCount < 10) {
            countCartTextView.setText(String.valueOf(alertCount));
        } else {
            countCartTextView.setText(""); // if alert count extends into two digits, just show the red circle
        }
        yellowCircleCart.setVisibility((alertCount > 0) ? VISIBLE : GONE);
    }

    public void cashout(View view) {

    }
}