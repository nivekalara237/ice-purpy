package com.nivekaa.paypalintegration.storage.entry;

import com.nivekaa.paypalintegration.model.ProductVM;

import java.math.BigDecimal;

public class ProductEntity {
    public static final String TABLE_NAME = "product_entry";
    public static final String COLUMN_NAME_NAME = "name";
    public static final String COLUMN_NAME_UUID = "_uuid";
    public static final String COLUMN_NAME_ID = "product_id";
    public static final String COLUMN_NAME_PRICE = "price";
    public static final String COLUMN_NAME_RATE = "rate";
    public static final String COLUMN_NAME_IMAGE = "image";

    public static class Entry {
        public String uuid;
        public Float price;
        public String image;
        public String name;
        public Integer id;
        public Float rate;

        public Entry() {
        }

        public Entry(String uuid, Float price, String image, String name, Float rate) {
            this.uuid = uuid;
            this.price = price;
            this.image = image;
            this.name = name;
            this.rate = rate;
        }
    }

    public static Entry vmToEntry(ProductVM vm){
        return new Entry(vm.getId(), vm.getPrice().floatValue(), vm.getImageUrl(), vm.getName(), vm.getRate());
    }

    public static ProductVM entryToVm(Entry entry) {
        return new ProductVM(entry.uuid, entry.name, BigDecimal.valueOf(entry.price), entry.rate, entry.image);
    }
}
