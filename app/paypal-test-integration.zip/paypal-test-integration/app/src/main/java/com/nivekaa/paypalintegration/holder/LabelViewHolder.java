package com.nivekaa.paypalintegration.holder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import com.nivekaa.paypalintegration.R;

public class LabelViewHolder extends RecyclerView.ViewHolder {
    public Button button;
    public LabelViewHolder(@NonNull View itemView) {
        super(itemView);
        button = (Button)itemView.findViewById(R.id.label);
    }
}
