package com.nivekaa.paypalintegration.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.nivekaa.paypalintegration.R;
import com.nivekaa.paypalintegration.holder.ProductViewHolder;
import com.nivekaa.paypalintegration.listener.OnAddToCartListener;
import com.nivekaa.paypalintegration.model.ProductVM;
import com.squareup.picasso.Picasso;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductViewHolder> {
    private List<ProductVM> products;
    private final Context context;
    private final OnAddToCartListener cartListener;
    public ProductAdapter(Context ctx, List<ProductVM> vms, OnAddToCartListener listener) {
        this.products = vms;
        this.context = ctx;
        this.cartListener = listener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_item, parent, false);
        return new ProductViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int i) {
        final ProductVM product = products.get(i);
        holder.rate.setRating(product.getRate());
        holder.name.setText(product.getName());
        holder.price.setText(product.getPrice().toPlainString());
        Picasso.with(context)
                //.setDebugging(true)
                .load(product.getImageUrl())
                //.rotate(-30)
                .error(R.drawable.shoe_nike_air_max_red_128dp)
                .into(holder.photo);
        holder.btnAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cartListener.addProduct(product);
            }
        });
    }

    @Override
    public int getItemCount() {
        return products.size();
    }
}
