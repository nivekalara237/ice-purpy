package com.nivekaa.paypalintegration.listener;

import com.nivekaa.paypalintegration.model.OrderItemVM;

public interface OnXxCreaseQteItemListener {
    void increase(OrderItemVM order);
    void decrease(OrderItemVM order);
}
