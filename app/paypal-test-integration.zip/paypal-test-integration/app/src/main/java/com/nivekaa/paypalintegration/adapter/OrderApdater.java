package com.nivekaa.paypalintegration.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.nivekaa.paypalintegration.R;
import com.nivekaa.paypalintegration.holder.OrderViewHolder;
import com.nivekaa.paypalintegration.listener.OnXxCreaseQteItemListener;
import com.nivekaa.paypalintegration.model.OrderItemVM;
import com.squareup.picasso.Picasso;

import java.util.List;

public class OrderApdater extends RecyclerView.Adapter<OrderViewHolder> {
    private final Context context;
    private final OnXxCreaseQteItemListener qteItemListener;
    private final List<OrderItemVM> orderItems;
    public OrderApdater(Context ctx, List<OrderItemVM> vms, OnXxCreaseQteItemListener listener) {
        this.context = ctx;
        this.orderItems = vms;
        this.qteItemListener = listener;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_item, parent, false);
        return new OrderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final OrderViewHolder holder, int i) {
        final OrderItemVM orderItem = orderItems.get(i);
        holder.qte.setText(String.valueOf(orderItem.getQuantity()));
        holder.name.setText(orderItem.getProduct().getName());
        holder.price.setText(String.valueOf(orderItem.getProduct().getPrice()));
        holder.increateQte.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String val = holder.qte.getText().toString();
                qteItemListener.increase(orderItem);
                holder.qte.setText(String.valueOf(Integer.parseInt(val) + 1));
            }
        }));
        holder.decreateQte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String val = holder.qte.getText().toString();
                if (val != null && Integer.parseInt(val)>0) {
                    qteItemListener.decrease(orderItem);
                    holder.qte.setText(String.valueOf(Integer.parseInt(val) - 1));
                }

            }
        });
        Picasso.with(context).load(orderItem.getProduct().getImageUrl())
                .error(R.drawable.shoe_nike_air_max_red_128dp)
                .into(holder.image);
    }

    @Override
    public int getItemCount() {
        return orderItems.size();
    }
}
