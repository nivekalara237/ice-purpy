package com.nivekaa.paypalintegration.adapter;

import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.nivekaa.paypalintegration.R;
import com.nivekaa.paypalintegration.holder.LabelViewHolder;
import com.nivekaa.paypalintegration.model.LabelVM;

import java.util.List;

public class LabelAdapter extends RecyclerView.Adapter<LabelViewHolder> {
    private List<LabelVM> labels;
    public LabelAdapter(List<LabelVM> vms) {
        this.labels = vms;
    }

    @NonNull
    @Override
    public LabelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.label_item, parent, false);
        return new LabelViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull LabelViewHolder labelViewHolder, int i) {
        LabelVM vm = labels.get(i);
        labelViewHolder.button.setText(vm.getTitle());
        if (vm.getColor() != null)
            labelViewHolder.button.setBackgroundColor(Color.parseColor(vm.getColor()));
    }

    @Override
    public int getItemCount() {
        return labels.size();
    }
}
