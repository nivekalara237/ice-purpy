package com.nivekaa.paypalintegration.model;

import java.math.BigDecimal;

public class ProductVM {
    private String id;
    private String name;
    private BigDecimal price;
    private Integer inStock;
    private Float rate;
    private String imageUrl;
    private String bgColor;

    public ProductVM() {
    }

    public ProductVM(String id, String name, BigDecimal price, Float rate, String imageUrl) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.rate = rate;
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getInStock() {
        return inStock;
    }

    public void setInStock(Integer inStock) {
        this.inStock = inStock;
    }

    public Float getRate() {
        return rate;
    }

    public void setRate(Float rate) {
        this.rate = rate;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getBgColor() {
        return bgColor;
    }

    public void setBgColor(String bgColor) {
        this.bgColor = bgColor;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "ProductVM{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", inStock=" + inStock +
                ", rate=" + rate +
                ", imageUrl='" + imageUrl + '\'' +
                ", bgColor='" + bgColor + '\'' +
                '}';
    }
}
