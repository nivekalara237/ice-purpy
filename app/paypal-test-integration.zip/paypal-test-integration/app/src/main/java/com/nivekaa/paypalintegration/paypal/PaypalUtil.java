package com.nivekaa.paypalintegration.paypal;

public class PaypalUtil {
    public static final String PAYPAL_CLIENT_ID = "Ad23sOCVDf4RxN_HeRwXbAf9PKrx7Z21kMJzpqCwjxODElMZN0KDaGlCDk4cNMtc9lLB3K_5OOJ2xNjW";
    //Paypal intent request code to track onActivityResult method
    public static final int PAYPAL_REQUEST_CODE = 123;
}
